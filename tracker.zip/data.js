const dungeons = [
    {
        name: 'FASZ dungeon',
        image: 'assets/asd.png',
        tier: 1,
        counter: 0,
        times: [2, 4224, 321]
    },
    {
        name: 'SEGG dungeon',
        image: 'assets/asd.png',
        tier: 2,
        counter: 0,
        times: [2, 42]
    },
]